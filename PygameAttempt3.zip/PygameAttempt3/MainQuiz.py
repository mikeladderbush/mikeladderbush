
import pygame
import os
from pygame import key
from pygame import rect
from pygame.constants import *
import time

from pygame.sprite import collide_rect

class dumby_defense_class(pygame.sprite.Sprite):
    def __init__(self, loc_x, loc_y):
        super().__init__()
        self.run_animation = False
        self.sprites = []
        pic1 = pygame.transform.scale(pygame.image.load('dumby1.png'), (50, 50))
        pic2 = pygame.transform.scale(pygame.image.load('dumby2.png'), (50, 50))
        pic3 = pygame.transform.scale(pygame.image.load('dumby3.png'), (50, 50))
        pic4 = pygame.transform.scale(pygame.image.load('dumby4.png'), (50, 50))
        pic5 = pygame.transform.scale(pygame.image.load('dumby5.png'), (50, 50))
        pic6 = pygame.transform.scale(pygame.image.load('dumby6.png'), (50, 50))
        pic7 = pygame.transform.scale(pygame.image.load('dumby7.png'), (50, 50))
        self.sprites.append(pic1)
        self.sprites.append(pic2)
        self.sprites.append(pic3)
        self.sprites.append(pic4)
        self.sprites.append(pic5)
        self.sprites.append(pic6)
        self.sprites.append(pic7)
        self.current_sprite = 0
        self.image = self.sprites[self.current_sprite]
        self.rect = self.image.get_rect()
        self.rect.topleft = [loc_x, loc_y]

    def push(self, x):

        self.rect.x = self.rect.x - x
        self.rect.y = self.rect.y - 1
        
    def chase(self, x, y):

            self.run_animation = True
            self.current_sprite += 0.1
            if self.rect.x == dumby.rect.x:
                self.rect.x = self.rect.x + x
                self.rect.y = self.rect.y + y
            else:
                if self.rect.x <= dumby.rect.x:
                    self.rect.x = self.rect.x + x
                if self.rect.x >= dumby.rect.x:
                    self.rect.x = self.rect.x - x
                if self.rect.y <= dumby.rect.y:
                    self.rect.y = self.rect.y + y
                if self.rect.y >= dumby.rect.y:
                    self.rect.y = self.rect.y - y

       
            self.run_animation = False
            self.current_sprite += 0
            
            if int(self.current_sprite) >= len(self.sprites):
                self.current_sprite = 0
                self.run_animation = False


            self.image = self.sprites[int(self.current_sprite)]
            
pygame.init()
clock = pygame.time.Clock()
Canvas = pygame.display.set_mode((750, 750))
pygame.display.set_caption('Dumby')
moving_sprites = pygame.sprite.Group()
dumbyLocX, dumbyLocY = (375,400)
dumbyLocX2, dumbyLocY2 = (375,350)
dumbyLocX3, dumbyLocY3 = (325,350)
dumbyLocX4, dumbyLocY4 = (275,350)
dumbyLocX5, dumbyLocY5 = (225,350)
dumbyLocX6, dumbyLocY6 = (175,350)
dumbyLocX7, dumbyLocY7 = (375,475)
dumbyLocX8, dumbyLocY8 = (425,350)
dumbyLocX9, dumbyLocY9 = (475,350)
dumbyLocX10, dumbyLocY10 = (525,350)
dumbyLocX11, dumbyLocY11 = (575,350)
dumbyLocX12, dumbyLocY12 = (325,150)
dumbyLocX13, dumbyLocY13 = (425,150)
dumbyLocX14, dumbyLocY14 = (325,290)
dumbyLocX15, dumbyLocY15 = (275,290)
dumbyLocX16, dumbyLocY16 = (225,290)
dumbyLocX17, dumbyLocY17 = (175,290)
dumbyLocX18, dumbyLocY18 = (375,290)
dumbyLocX19, dumbyLocY19 = (425,290)
dumbyLocX20, dumbyLocY20 = (475,290)
dumbyLocX21, dumbyLocY21 = (525,290)
dumbyLocX22, dumbyLocY22 = (575,290)

dumby = dumby_defense_class(dumbyLocX, dumbyLocY)
dumby2 = dumby_defense_class(dumbyLocX2, dumbyLocY2)
dumby3 = dumby_defense_class(dumbyLocX3, dumbyLocY3)
dumby4 = dumby_defense_class(dumbyLocX4, dumbyLocY4)
dumby5 = dumby_defense_class(dumbyLocX5, dumbyLocY5)
dumby6 = dumby_defense_class(dumbyLocX6, dumbyLocY6)
dumby7 = dumby_defense_class(dumbyLocX7, dumbyLocY7)
dumby8 = dumby_defense_class(dumbyLocX8, dumbyLocY8)
dumby9 = dumby_defense_class(dumbyLocX9, dumbyLocY9)
dumby10 = dumby_defense_class(dumbyLocX10, dumbyLocY10)
dumby11 = dumby_defense_class(dumbyLocX11, dumbyLocY11)
dumby12 = dumby_defense_class(dumbyLocX12, dumbyLocY12)
dumby13 = dumby_defense_class(dumbyLocX13, dumbyLocY13)
dumby14 = dumby_defense_class(dumbyLocX14, dumbyLocY14)
dumby15 = dumby_defense_class(dumbyLocX15, dumbyLocY15)
dumby16 = dumby_defense_class(dumbyLocX16, dumbyLocY16)
dumby17 = dumby_defense_class(dumbyLocX17, dumbyLocY17)
dumby18 = dumby_defense_class(dumbyLocX18, dumbyLocY18)
dumby19 = dumby_defense_class(dumbyLocX19, dumbyLocY19)
dumby20 = dumby_defense_class(dumbyLocX20, dumbyLocY20)
dumby21 = dumby_defense_class(dumbyLocX21, dumbyLocY21)
dumby22 = dumby_defense_class(dumbyLocX22, dumbyLocY22)

moving_sprites.add(dumby, dumby2, dumby3, dumby4, dumby5, dumby6, dumby7, dumby8, dumby9, dumby10, dumby11, dumby12, dumby13, dumby14,
dumby15, dumby16, dumby17, dumby18, dumby19, dumby20, dumby21, dumby22)
Step = 5
FPS = 60

running = True

while running == True:
    dumby.chase(0, 0)
    dumby7.chase(0, 0)

    if dumby22.rect.x < dumby11.rect.x + 25 < dumby22.rect.x + 50:
        dumby22.chase(1, 1)
    else:
        if dumby22.rect.x < dumby10.rect.x + 40 and dumby22.rect.y < dumby10.rect.y:
            dumby22.push(-2)
            dumby22.chase(1, 1)
        else: 
            dumby22.chase(1, 1)

    if dumby21.rect.x < dumby10.rect.x + 25 < dumby21.rect.x + 50:
        dumby21.chase(1, 1)
    else:
        if dumby21.rect.x < dumby9.rect.x + 40 and dumby21.rect.y < dumby9.rect.y:
            dumby21.push(-2)
            dumby21.chase(1, 1)
        else: 
            dumby21.chase(1, 1)

    if dumby20.rect.x < dumby9.rect.x + 25 < dumby20.rect.x + 50:
        dumby20.chase(1, 1)
    else:
        if dumby20.rect.x < dumby8.rect.x + 40 and dumby20.rect.y < dumby8.rect.y:
            dumby20.push(-2)
            dumby20.chase(1, 1)
        else: 
            dumby20.chase(1, 1)

    if dumby19.rect.x < dumby8.rect.x + 25 < dumby19.rect.x + 50:
        dumby19.chase(1, 1)
    else:
        if dumby19.rect.x < dumby2.rect.x + 40 and dumby19.rect.y < dumby2.rect.y:
            dumby19.push(-2)
            dumby19.chase(1, 1)
        else: 
            dumby19.chase(1, 1)

    if dumby18.rect.x == dumby2.rect.x:
        dumby18.push(-2)
        dumby18.chase(1, 1)
    else:
        dumby18.chase(1, 1)

    if dumby17.rect.x < dumby6.rect.x + 25 < dumby17.rect.x + 50:
        dumby17.chase(1, 1)
    else:
        if dumby17.rect.x < dumby5.rect.x + 40 and dumby17.rect.y < dumby5.rect.y:
            dumby17.push(2)
            dumby17.chase(1, 1)
        else: 
            dumby17.chase(1, 1)

    if dumby16.rect.x < dumby5.rect.x + 25 < dumby16.rect.x + 50:
        dumby16.chase(1, 1)
    else:
        if dumby16.rect.x < dumby4.rect.x + 40 and dumby16.rect.y < dumby4.rect.y:
            dumby16.push(2)
            dumby16.chase(1, 1)
        else: 
            dumby16.chase(1, 1)

    if dumby15.rect.x < dumby4.rect.x + 25 < dumby15.rect.x + 50:
        dumby15.chase(1, 1)
    else:
        if dumby15.rect.x < dumby3.rect.x + 40 and dumby15.rect.y < dumby3.rect.y:
            dumby15.push(2)
            dumby15.chase(1, 1)
        else: 
            dumby15.chase(1, 1)

    if dumby14.rect.x < dumby3.rect.x + 25 < dumby14.rect.x + 50:
        dumby14.chase(1, 1)
    else:
        if dumby14.rect.x < dumby2.rect.x + 40 and dumby14.rect.y < dumby2.rect.y:
            dumby14.push(2)
            dumby14.chase(1, 1)
        else: 
            dumby14.chase(1, 1)


    for event in pygame.event.get():

        keys_pressed = pygame.key.get_pressed()

        if keys_pressed[K_ESCAPE]:
            running = False

        if event.type == pygame.QUIT:
            running = False

        if keys_pressed[K_a]:
            dumby.chase(-1, 0)

            if keys_pressed[K_d]:
                continue
            else:
                dumby.chase(-1, 0)

        if keys_pressed[K_s]:
            if keys_pressed[K_w]:
                continue
            else:
                dumby.chase(0, 1)

        if keys_pressed[K_d]:

            if keys_pressed[K_a]:
                continue

            else:
                dumby.chase(1, 0)

        if keys_pressed[K_w]:

            if keys_pressed[K_s]:
                continue

            else:
                dumby.chase(0, -1)

    Canvas.fill((0, 0, 0))
    moving_sprites.draw(Canvas)
    moving_sprites.update()

    clock.tick(FPS)
    moving_sprites.draw(Canvas)
    pygame.display.update()

