
import pygame
from pygame.constants import *

pygame.init()
Canvas = pygame.display.set_mode((750, 750))
pygame.display.set_caption('Dumby')
option1 = pygame.Rect(50, 50, 175, 25)
option2 = pygame.Rect(50, 100, 175, 25)
Canvas.fill((0, 0, 0))
smallfont = pygame.font.SysFont('Corbel', 24) 
text = smallfont.render('Press 1 for play 1' , True, (0, 0, 0)) 
text2 = smallfont.render('Press 2 for play 2', True, (0, 0, 0))
pygame.draw.rect(Canvas, (255, 255, 255), option1)
pygame.draw.rect(Canvas, (255, 255, 255), option2)
Canvas.blit(text, (50, 50))
Canvas.blit(text2, (50, 100))

running = True
while running == True:
    for event in pygame.event.get():

        keys_pressed = pygame.key.get_pressed()

        if event.type == QUIT:
            raise SystemExit

        if keys_pressed[K_1]:
            import MainQuiz
            #play one
            
        if keys_pressed[K_2]:
            import MainQuiz
            #play two

        pygame.display.flip()