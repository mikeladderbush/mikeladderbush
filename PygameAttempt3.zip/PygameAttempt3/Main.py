import pygame
import os
from pygame.constants import *

pygame.init()
pygame.display.init()
canvas = pygame.display.set_mode((500, 500))
pygame.display.set_caption("Monkey Boys")
Mongy_Image = pygame.image.load('mongy1.png')
Mongy_Image = pygame.transform.scale(Mongy_Image, (50, 50))
Mongy = Mongy_Image.get_rect()

running = True
while running == True:
    for event in pygame.event.get():
        keys_pressed = pygame.key.get_pressed()
        if keys_pressed[K_ESCAPE]:
            running = False
        if event.type == pygame.QUIT:
            running = False  

    canvas.blit(Mongy_Image, Mongy)
    pygame.display.update()
